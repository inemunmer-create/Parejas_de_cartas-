"""Plantilla con las funciones que el alumnado debe completar para M3.

La capa gráfica llama a estas funciones para mover el estado del juego. No es
necesario crear clases; basta con manipular listas, diccionarios y tuplas.
"""
from __future__ import annotations

import random
from typing import Dict, List, Tuple

STATE_HIDDEN = "hidden"
STATE_VISIBLE = "visible"
STATE_FOUND = "found"

Card = Dict[str, str]
Board = List[List[Card]]
Position = Tuple[int, int]
GameState = Dict[str, object]


def build_symbol_pool(rows: int, cols: int) -> List[str]:
    """Crea la lista de símbolos necesaria para rellenar todo el tablero.

    Sugerencia: parte de un listado básico de caracteres y duplícalo tantas
    veces como parejas necesites. Después baraja el resultado.
    """
    total_pairs = (rows * cols) // 2
    symbols = [str(i) for i in range(total_pairs)]
    symbol_pool = symbols * 2
    random.shuffle(symbol_pool)
    return symbol_pool


def create_game(rows: int, cols: int) -> GameState:
    """Genera el diccionario con el estado inicial del juego.

    El estado debe incluir:
    - ``board``: lista de listas con cartas (cada carta es un dict con
      ``symbol`` y ``state``).
    - ``pending``: lista de posiciones descubiertas en el turno actual.
    - ``moves``: contador de movimientos realizados.
    - ``matches``: parejas acertadas.
    - ``total_pairs``: número total de parejas disponibles.
    - ``rows`` / ``cols``: dimensiones del tablero.
    """
    symbol_pool = build_symbol_pool(rows, cols)
    board: Board = []
    idx = 0
    
    for row in range(rows):
        row_cards: List[Card] = []
        for col in range(cols):
            card: Card = {
                "symbol": symbol_pool[idx],
                "state": STATE_HIDDEN
            }
            row_cards.append(card)
            idx += 1
        board.append(row_cards)
    
    total_pairs = (rows * cols) // 2
    game_state: GameState = {
        "board": board,
        "pending": [],
        "moves": 0,
        "matches": 0,
        "total_pairs": total_pairs,
        "rows": rows,
        "cols": cols
    }
    return game_state


def reveal_card(game: GameState, row: int, col: int) -> bool:
    """Intenta descubrir la carta ubicada en ``row``, ``col``.

    Debe devolver ``True`` si el estado ha cambiado (es decir, la carta estaba
    oculta y ahora está visible) y ``False`` en cualquier otro caso. No permitas
    dar la vuelta a más de dos cartas simultáneamente.
    """
    rows = game["rows"]
    cols = game["cols"]
    pending = game["pending"]
    board = game["board"]
    
    # Validar coordenadas
    if row < 0 or row >= rows or col < 0 or col >= cols:
        return False
    
    # No permitir más de dos cartas visibles
    if len(pending) >= 2:
        return False
    
    # No permitir revelar la misma carta dos veces
    if (row, col) in pending:
        return False
    
    card = board[row][col]
    
    # Solo revelar cartas ocultas
    if card["state"] != STATE_HIDDEN:
        return False
    
    # Revelar la carta
    card["state"] = STATE_VISIBLE
    pending.append((row, col))
    return True


def resolve_pending(game: GameState) -> Tuple[bool, bool]:
    """Resuelve el turno si hay dos cartas pendientes.

    Devuelve una tupla ``(resuelto, pareja_encontrada)``. Este método debe
    ocultar las cartas si son diferentes o marcarlas como ``found`` cuando
    coincidan. Además, incrementa ``moves`` y ``matches`` según corresponda.
    """
    pending = game["pending"]
    board = game["board"]
    
    # Solo resolver si hay exactamente dos cartas pendientes
    if len(pending) != 2:
        return (False, False)
    
    row1, col1 = pending[0]
    row2, col2 = pending[1]
    
    card1 = board[row1][col1]
    card2 = board[row2][col2]
    
    # Comprobar si las cartas coinciden
    if card1["symbol"] == card2["symbol"]:
        # Pareja encontrada
        card1["state"] = STATE_FOUND
        card2["state"] = STATE_FOUND
        game["matches"] += 1
        pareja_encontrada = True
    else:
        # No coinciden, ocultar de nuevo
        card1["state"] = STATE_HIDDEN
        card2["state"] = STATE_HIDDEN
        pareja_encontrada = False
    
    # Incrementar movimientos y limpiar pending
    game["moves"] += 1
    game["pending"] = []
    
    return (True, pareja_encontrada)


def has_won(game: GameState) -> bool:
    """Indica si se han encontrado todas las parejas."""
    return game["matches"] == game["total_pairs"]